# Terms of Use
Understory is provided “as is,” without warranties of any kind. All articles remain the property of Moss & Fog or their respective authors.
You may not use this app for unlawful purposes. We reserve the right to update or change these terms at any time.
