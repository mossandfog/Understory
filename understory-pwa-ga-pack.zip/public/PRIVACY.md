# Privacy Policy
We respect your privacy. Understory collects minimal data — only what's necessary to save your preferences, sync collections, and improve your experience.
We use Google Analytics to understand general usage trends, not to track you personally. Your saved articles and collections are stored securely
and are never sold or shared with third parties. By using this app, you agree to this policy.
