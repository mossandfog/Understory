# Understory PWA + GA Pack (Drop-in)

This folder contains everything you need to make the app installable (PWA), show an icon, enable offline cache,
add a favicon, and include Privacy/Terms — plus Google Analytics.

## Files to upload to your repo
Upload the entire `public/` folder into your repo (create it if it doesn't exist):

- `public/manifest.webmanifest`
- `public/sw.js`
- `public/favicon.ico`
- `public/icons/*` (multiple sizes)
- `public/PRIVACY.md`
- `public/TERMS.md`

## Edit index.html
1. Open `index.html` in your repo.
2. Copy-paste the contents of `index-head-snippet.html` **inside the <head>** tag.
   - Replace **G-XXXXX** with your GA Measurement ID (looks like G-ABC123XYZ).
3. Copy-paste the contents of `index-body-snippet.html` **right before </body>**.

## Vercel deploy
- In Vercel → Project Settings → Environment Variables, add:
  - `VITE_SUPABASE_URL` = your Supabase project URL
  - `VITE_SUPABASE_ANON_KEY` = your Supabase anon key
- Redeploy.

## Supabase
- In Supabase Auth → Providers: enable Google, add redirect URLs: http://localhost:5173 and your Vercel domain.
- Run the SQL from the app file header to create tables and RLS.

## Done!
- Visit your app. Chrome/Android will offer “Install App”; iOS will via Share → Add to Home Screen.
- Privacy and Terms are available at `/PRIVACY.md` and `/TERMS.md`.
